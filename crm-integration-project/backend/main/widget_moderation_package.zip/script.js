(function () {
  'use strict';

  var API_BASE = 'https://corsa-crm.ru';

  function getAccountSubdomain() {
    try {
      if (window.AMOCRM && window.AMOCRM.constant && window.AMOCRM.constant('account').subdomain) {
        return window.AMOCRM.constant('account').subdomain;
      }
    } catch (e) {}
    return '';
  }

  function openCorsaCabinet(path) {
    var target = API_BASE + (path || '/dashboard');
    window.open(target, '_blank');
  }

  return this;
}).call({
  callbacks: {
    settings: function () {
      return true;
    },

    init: function () {
      return true;
    },

    bind_actions: function () {
      return true;
    },

    render: function () {
      var self = this;
      var subdomain = (function () {
        try {
          return AMOCRM.constant('account').subdomain || '';
        } catch (e) {
          return '';
        }
      })();

      if (self.system && self.system().area === 'settings') {
        self.render_template({
          caption: self.i18n('widget.name'),
          body: '<div style="padding:12px 0;">' +
            '<p style="margin:0 0 10px;">' + self.i18n('widget.description') + '</p>' +
            '<a href="https://corsa-crm.ru/dashboard" target="_blank" style="color:#2e6be6;text-decoration:none;">' +
            self.i18n('settings.open_dashboard') +
            '</a>' +
            '</div>'
        });
        return true;
      }

      if (self.system && self.system().area === 'widget_page') {
        window.location.href = 'https://corsa-crm.ru/widget-page?subdomain=' + encodeURIComponent(subdomain);
        return true;
      }

      return true;
    },

    contacts: {
      selected: function () {
        return true;
      }
    },

    onSave: function () {
      return true;
    }
  }
});
