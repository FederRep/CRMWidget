define(['jquery'], function () {
  'use strict';

  var API_BASE = 'https://corsa-crm.ru';
  var SCRIPT_DEBUG_VERSION = '1.2.1';

  function injectGlobalDebugBadge() {
    try {
      if (!window || !document || !document.body) return;
      if (document.getElementById('corsa-widget-debug-badge')) return;
      var p = window.location && window.location.pathname ? window.location.pathname : '';
      if (p.indexOf('/widget_page/') === -1) return;

      var badge = document.createElement('div');
      badge.id = 'corsa-widget-debug-badge';
      badge.style.position = 'fixed';
      badge.style.right = '12px';
      badge.style.top = '12px';
      badge.style.zIndex = '2147483647';
      badge.style.padding = '8px 10px';
      badge.style.border = '1px solid #ffd36b';
      badge.style.background = '#fff8e1';
      badge.style.color = '#6b4e00';
      badge.style.borderRadius = '8px';
      badge.style.fontSize = '12px';
      badge.style.fontFamily = 'Arial, sans-serif';
      badge.textContent = 'Corsa AMD script loaded v' + SCRIPT_DEBUG_VERSION;
      document.body.appendChild(badge);
    } catch (e) {}
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', injectGlobalDebugBadge);
    } else {
      injectGlobalDebugBadge();
    }
  }

  function buildCabinetUrl(subdomain) {
    var target = API_BASE + '/dashboard';
    var qs = [];
    if (subdomain) qs.push('subdomain=' + encodeURIComponent(subdomain));
    qs.push('source=amocrm_widget');
    return target + (qs.length ? ('?' + qs.join('&')) : '');
  }

  function getSubdomain() {
    try {
      return AMOCRM.constant('account').subdomain || '';
    } catch (e) {
      return '';
    }
  }

  function buildWidgetPageHtml(subdomain, modeLabel) {
    var hubUrl = API_BASE + '/widget-page?embedded=1&subdomain=' + encodeURIComponent(subdomain);
    return '<div style="padding:8px 10px;margin:0 0 8px;border:1px solid #ffd36b;background:#fff8e1;border-radius:8px;font-size:12px;line-height:1.4;color:#6b4e00;">' +
      'WAZZUP-STYLE v' + SCRIPT_DEBUG_VERSION + ': ' + modeLabel + '. ' +
      'subdomain=' + (subdomain || 'none') + '. ' +
      '<a href="' + hubUrl + '" target="_blank" style="margin-left:6px;color:#2e6be6;text-decoration:underline;">Open widget-page</a>' +
      '</div>' +
      '<div style="min-height:520px;width:100%;box-sizing:border-box;">' +
      '<iframe src="' + hubUrl + '" title="Corsa" ' +
      'style="width:100%;height:560px;border:0;border-radius:8px;background:#fff;display:block;"></iframe>' +
      '</div>';
  }

  function markCallback(label) {
    try {
      if (!document || !document.body) return;
      var id = 'corsa-callback-marker-' + label.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      if (document.getElementById(id)) return;

      var marker = document.createElement('div');
      marker.id = id;
      marker.style.position = 'fixed';
      marker.style.right = '12px';
      marker.style.top = label === 'RENDER reached' ? '52px' : '92px';
      marker.style.zIndex = '2147483647';
      marker.style.padding = '6px 10px';
      marker.style.border = '1px solid #9ec5fe';
      marker.style.background = '#e7f1ff';
      marker.style.color = '#084298';
      marker.style.borderRadius = '8px';
      marker.style.fontSize = '12px';
      marker.style.fontFamily = 'Arial, sans-serif';
      marker.textContent = 'Corsa v' + SCRIPT_DEBUG_VERSION + ': ' + label;
      document.body.appendChild(marker);
    } catch (e) {}
  }

  var CustomWidget = function () {
    var self = this;

    this.callbacks = {
      settings: function () {
        return true;
      },

      init: function () {
        return true;
      },

      bind_actions: function () {
        return true;
      },

      render: function () {
        markCallback('RENDER reached');

        var subdomain = getSubdomain();

        var area = '';
        try {
          area = (self.system && self.system().area) || '';
        } catch (e2) {}

        var cabinetUrl = buildCabinetUrl(subdomain);
        if (area === 'settings') {
          var settingsHtml = '<div style="padding:12px 0;">' +
            '<p style="margin:0 0 10px;">' + self.i18n('widget.description') + '</p>' +
            '<p style="margin:0 0 12px;font-size:13px;color:#666;">Поддомен amoCRM: <strong>' +
            (subdomain || '-') + '</strong></p>' +
            '<a href="' + cabinetUrl + '" target="_blank" ' +
            'style="display:inline-block;padding:10px 14px;background:#2e6be6;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;">' +
            self.i18n('settings.open_dashboard') +
            '</a>' +
            '</div>';
          self.render_template({
            caption: self.i18n('widget.name'),
            body: settingsHtml
          });
          return true;
        }

        var skipIframe = { advanced_settings: true, digital_pipeline: true, salesbot_designer: true };
        if (skipIframe[area]) {
          return true;
        }

        self.render_template({
          caption: self.i18n('widget.name'),
          body: buildWidgetPageHtml(subdomain, 'render callback')
        });
        return true;
      },

      contacts: {
        selected: function () {
          return true;
        }
      },

      onSave: function () {
        return true;
      },

      initMenuPage: function (params) {
        markCallback('INIT_MENU_PAGE entered');

        if (!params || params.location !== 'widget_page') {
          return true;
        }

        if (params.item_code && params.item_code !== 'corsa_telegram_hub') {
          return true;
        }

        markCallback('INIT_MENU_PAGE reached');

        var subdomain = getSubdomain();
        var widgetCode = '';
        try {
          widgetCode = self.get_settings().widget_code;
        } catch (e) {}

        var selector = widgetCode ? ('#work-area-' + widgetCode) : '';
        if (selector && window.jQuery && window.jQuery(selector).length) {
          window.jQuery(selector).html(buildWidgetPageHtml(subdomain, 'initMenuPage callback'));
          return true;
        }

        // Fallback for old menu rendering paths.
        self.render_template({
          caption: self.i18n('widget.name'),
          body: buildWidgetPageHtml(subdomain, 'initMenuPage fallback')
        });
        return true;
      }
    };

    return this;
  };

  return CustomWidget;
});
