(function () {
  'use strict';

  var API_BASE = 'https://corsa-crm.ru';
  var SCRIPT_DEBUG_VERSION = '1.0.7';

  function injectGlobalDebugBadge() {
    try {
      if (!window || !document || !document.body) return;
      if (document.getElementById('corsa-widget-debug-badge')) return;
      var p = window.location && window.location.pathname ? window.location.pathname : '';
      if (p.indexOf('/widget_page/') === -1) return;

      var badge = document.createElement('div');
      badge.id = 'corsa-widget-debug-badge';
      badge.style.position = 'fixed';
      badge.style.right = '12px';
      badge.style.top = '12px';
      badge.style.zIndex = '2147483647';
      badge.style.padding = '8px 10px';
      badge.style.border = '1px solid #ffd36b';
      badge.style.background = '#fff8e1';
      badge.style.color = '#6b4e00';
      badge.style.borderRadius = '8px';
      badge.style.fontSize = '12px';
      badge.style.fontFamily = 'Arial, sans-serif';
      badge.textContent = 'Corsa script.js loaded v' + SCRIPT_DEBUG_VERSION;
      document.body.appendChild(badge);
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectGlobalDebugBadge);
  } else {
    injectGlobalDebugBadge();
  }

  function getAccountSubdomain() {
    try {
      if (window.AMOCRM && window.AMOCRM.constant && window.AMOCRM.constant('account').subdomain) {
        return window.AMOCRM.constant('account').subdomain;
      }
    } catch (e) {}
    return '';
  }

  function buildCabinetUrl(subdomain) {
    var target = API_BASE + '/dashboard';
    var qs = [];
    if (subdomain) qs.push('subdomain=' + encodeURIComponent(subdomain));
    qs.push('source=amocrm_widget');
    return target + (qs.length ? ('?' + qs.join('&')) : '');
  }

  return this;
}).call({
  callbacks: {
    settings: function () {
      return true;
    },

    init: function () {
      return true;
    },

    bind_actions: function () {
      return true;
    },

    render: function () {
      var self = this;
      var subdomain = '';
      try {
        subdomain = AMOCRM.constant('account').subdomain || '';
      } catch (e) {}

      var area = '';
      try {
        area = (self.system && self.system().area) || '';
      } catch (e2) {}

      var cabinetUrl = buildCabinetUrl(subdomain);

      // В amoCRM не должно быть этапов настройки, кроме установки из amoMarket.
      // Настройка каналов — только на сайте Corsa, а рабочий интерфейс — в iframe виджета.
      if (area === 'settings') {
        var settingsHtml = '<div style="padding:12px 0;">' +
          '<p style="margin:0 0 10px;">' + self.i18n('widget.description') + '</p>' +
          '<p style="margin:0 0 12px;font-size:13px;color:#666;">Поддомен amoCRM: <strong>' +
          (subdomain || '—') + '</strong></p>' +
          '<p style="margin:0 0 12px;font-size:13px;color:#444;">' +
          'Подключение Telegram и первичная настройка выполняются в личном кабинете Corsa.' +
          '</p>' +
          '<a href="' + cabinetUrl + '" target="_blank" ' +
          'style="display:inline-block;padding:10px 14px;background:#2e6be6;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;">' +
          self.i18n('settings.open_dashboard') +
          '</a>' +
          '</div>';
        self.render_template({
          caption: self.i18n('widget.name'),
          body: settingsHtml
        });
        return true;
      }

      var skipIframe = { advanced_settings: true, digital_pipeline: true, salesbot_designer: true };
      if (skipIframe[area]) {
        return true;
      }

      var hubUrl = API_BASE + '/widget-page?embedded=1&subdomain=' + encodeURIComponent(subdomain);
      var iframeHtml = '<div style="padding:8px 10px;margin:0 0 8px;border:1px solid #ffd36b;background:#fff8e1;border-radius:8px;font-size:12px;line-height:1.4;color:#6b4e00;">' +
        'DEBUG WIDGET v' + SCRIPT_DEBUG_VERSION + ': render callback reached. ' +
        'subdomain=' + (subdomain || 'none') + '. ' +
        '<a href="' + hubUrl + '" target="_blank" style="margin-left:6px;color:#2e6be6;text-decoration:underline;">Open widget-page</a>' +
        '</div>' +
        '<div style="min-height:520px;width:100%;box-sizing:border-box;">' +
        '<iframe src="' + hubUrl + '" title="Corsa" ' +
        'style="width:100%;height:560px;border:0;border-radius:8px;background:#fff;display:block;"></iframe>' +
        '</div>';

      self.render_template({
        caption: self.i18n('widget.name'),
        body: iframeHtml
      });
      return true;
    },

    contacts: {
      selected: function () {
        return true;
      }
    },

    onSave: function () {
      return true;
    }
  }
});
