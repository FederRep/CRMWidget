(function () {
  'use strict';

  var API_BASE = 'https://corsa-crm.ru';

  function getAccountSubdomain() {
    try {
      if (window.AMOCRM && window.AMOCRM.constant && window.AMOCRM.constant('account').subdomain) {
        return window.AMOCRM.constant('account').subdomain;
      }
    } catch (e) {}
    return '';
  }

  function buildCabinetUrl(subdomain) {
    var target = API_BASE + '/dashboard';
    var qs = [];
    if (subdomain) qs.push('subdomain=' + encodeURIComponent(subdomain));
    qs.push('source=amocrm_widget');
    return target + (qs.length ? ('?' + qs.join('&')) : '');
  }

  return this;
}).call({
  callbacks: {
    settings: function () {
      return true;
    },

    init: function () {
      return true;
    },

    bind_actions: function () {
      return true;
    },

    render: function () {
      var self = this;
      var subdomain = '';
      try {
        subdomain = AMOCRM.constant('account').subdomain || '';
      } catch (e) {}

      var area = '';
      try {
        area = (self.system && self.system().area) || '';
      } catch (e2) {}

      var cabinetUrl = buildCabinetUrl(subdomain);

      // В amoCRM не должно быть этапов настройки, кроме установки из amoMarket.
      // Настройка каналов — только на сайте Corsa, а рабочий интерфейс — в iframe виджета.
      if (area === 'settings') {
        var settingsHtml = '<div style="padding:12px 0;">' +
          '<p style="margin:0 0 10px;">' + self.i18n('widget.description') + '</p>' +
          '<p style="margin:0 0 12px;font-size:13px;color:#666;">Поддомен amoCRM: <strong>' +
          (subdomain || '—') + '</strong></p>' +
          '<p style="margin:0 0 12px;font-size:13px;color:#444;">' +
          'Подключение Telegram и первичная настройка выполняются в личном кабинете Corsa.' +
          '</p>' +
          '<a href="' + cabinetUrl + '" target="_blank" ' +
          'style="display:inline-block;padding:10px 14px;background:#2e6be6;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;">' +
          self.i18n('settings.open_dashboard') +
          '</a>' +
          '</div>';
        self.render_template({
          caption: self.i18n('widget.name'),
          body: settingsHtml
        });
        return true;
      }

      var skipIframe = { advanced_settings: true, digital_pipeline: true, salesbot_designer: true };
      if (skipIframe[area]) {
        return true;
      }

      var hubUrl = API_BASE + '/widget-page?embedded=1&subdomain=' + encodeURIComponent(subdomain);
      var iframeHtml = '<div style="min-height:520px;width:100%;box-sizing:border-box;">' +
        '<iframe src="' + hubUrl + '" title="Corsa" ' +
        'style="width:100%;height:560px;border:0;border-radius:8px;background:#fff;display:block;"></iframe>' +
        '</div>';

      self.render_template({
        caption: self.i18n('widget.name'),
        body: iframeHtml
      });
      return true;
    },

    contacts: {
      selected: function () {
        return true;
      }
    },

    onSave: function () {
      return true;
    }
  }
});
